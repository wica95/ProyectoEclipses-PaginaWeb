fetch("./assets/data/Noticias.json").then(function(resp) {
    return resp.json();
})
.then(function(data){
    for (const i in data){
        var x = "titulo-noticia-" + i;
        var y = "subtitulo-noticia-" + i;
        var z = "img" + i;
        document.getElementById(x).innerHTML = data[i].titulo;
        document.getElementById(y).innerHTML = data[i].subtitulo;
        document.getElementById(z).src=data[i].imagen;
    }
});

/* RECORTAR TEXTO DE NOTICIA
function truncateText(selector, maxLength) {
    var element = document.querySelector(selector),
        truncated = element.innerText;

    if (truncated.length > maxLength) {
        truncated = truncated.substr(0,maxLength) + '...';
    }
    return truncated;
}
//You can then call the function with something like what i have below.
document.querySelector('p.card-text').innerText = truncateText('p.card-text', 107);
*/