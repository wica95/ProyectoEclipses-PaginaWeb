$(function () {
    $(document).scroll(function () {
      var $nav = $(".navbar");
      $nav.toggleClass('scrolled', $(this).scrollTop() > $nav.height());
    });
  });

fetch('./assets/data/Noticias.json').then(function(resp) {
  return resp.json();
})
.then(function(data){
  
  //Primer Noticia que aparece en index
  var x = 0;
  document.getElementById('titulo1-noticia').innerHTML = data[x].titulo;
  document.getElementById('texto1-noticia').innerHTML = data[x].subtitulo;
  document.getElementById("img1").src=data[x].imagen;

  var y = 4;
  //Segunda Noticia que aparece en index
  document.getElementById('titulo2-noticia').innerHTML = data[y].titulo;
  document.getElementById('texto2-noticia').innerHTML = data[y].subtitulo;
  document.getElementById("img2").src=data[y].imagen;
});

function navbarColor(){
  var $nav = $(".navbar");
  console.log($nav.css('background-color'));
  if($nav.css('background-color') == "rgb(0, 0, 0)") {
    setTimeout(function(){
      $nav.css('background-color', "rgba(0, 0, 0, 0)");
    }, 300);
    
  } else {
    $nav.css('background-color', "rgb(0, 0, 0)");
  }
}