/*$(function () {
    $(document).scroll(function () {
      var $nav = $(".navbar");
      $nav.toggleClass('scrolled', $(this).scrollTop() > $nav.height());
    });
});*/

$(function () {
  function getEclipseDate(date) {
    var diferencia = date.getTime() - Date.now();
    return new Date(new Date().valueOf() + diferencia);
  }

  var eclipse23 = new Date(2023, 9, 14, 12, 9, 21); //Año, Mes, Dia, Hora, Min, Seg.
  var eclipse24 = new Date(2024, 3, 8, 13, 14, 10); //Año, Mes, Dia, Hora, Min, Seg.

  $('#clock-2023').countdown(getEclipseDate(eclipse23), function(event) {
  var $this = $(this).html(event.strftime(''
    + '<div class="box">'
    + '<span class="num">%D</span>'
    + '<span class="text">Dia%!d</span>'
    + '</div>'
    + '<div class="box">'
    + '<span class="num">%H</span>'
    + '<span class="text">Hora%!d</span>'
    + '</div>'
    + '<div class="box">'
    + '<span class="num">%M</span>'
    + '<span class="text">Minuto%!d</span>'
    + '</div>'
    + '<div class="box">'
    + '<span class="num">%S</span>'
    + '<span class="text">Segundo%!d</span>'
    + '</div>'));
  });

  $('#clock-2024').countdown(getEclipseDate(eclipse24), function(event) {
    var $this = $(this).html(event.strftime(''
    + '<div class="box">'
    + '<span class="num">%D</span>'
    + '<span class="text">Dia%!d</span>'
    + '</div>'
    + '<div class="box">'
    + '<span class="num">%H</span>'
    + '<span class="text">Hora%!d</span>'
    + '</div>'
    + '<div class="box">'
    + '<span class="num">%M</span>'
    + '<span class="text">Minuto%!d</span>'
    + '</div>'
    + '<div class="box">'
    + '<span class="num">%S</span>'
    + '<span class="text">Segundo%!d</span>'
    + '</div>'));
  });
});
